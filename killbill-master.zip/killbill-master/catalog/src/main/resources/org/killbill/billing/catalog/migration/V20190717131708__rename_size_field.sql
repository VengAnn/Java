alter table catalog_override_block_definition change size bsize decimal(15,9) NOT NULL;
