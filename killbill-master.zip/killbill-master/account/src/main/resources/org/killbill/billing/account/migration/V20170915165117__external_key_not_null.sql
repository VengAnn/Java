alter table accounts modify external_key varchar(255) NOT NULL;
alter table account_history modify external_key varchar(255) NOT NULL;
